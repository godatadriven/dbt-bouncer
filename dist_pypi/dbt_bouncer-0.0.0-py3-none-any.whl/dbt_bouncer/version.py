def version() -> str:
    return "0.0.0"
